# ModernPascalEditor
Cross-Platform GUI Editors for Modern Pascal Development - built in TideSDK

* More complete version coming - we have switched back to working on the IDE.
